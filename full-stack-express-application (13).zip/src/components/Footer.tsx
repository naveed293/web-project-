import { ShoppingBag } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-white/[.06] mt-auto bg-[#0c1220]/60">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="bg-emerald-500/15 p-1.5 rounded-lg border border-emerald-500/20"><ShoppingBag className="w-3.5 h-3.5 text-emerald-400" /></div>
            <span className="text-sm text-slate-500">ShopVault — Full Stack Express App</span>
          </div>
          <span className="text-xs text-slate-600">Node.js · Express · MongoDB · EJS · TailwindCSS · Passport.js</span>
        </div>
      </div>
    </footer>
  );
}

import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShoppingBag, LogOut, Plus, User, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const loc = useLocation();
  const [open, setOpen] = useState(false);
  const go = () => { logout(); navigate('/login'); setOpen(false); };
  const on = (p: string) => loc.pathname === p;

  return (
    <nav className="bg-[#0c1220]/90 backdrop-blur-xl border-b border-white/[.06] sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2.5 group" onClick={() => setOpen(false)}>
            <div className="bg-emerald-500 p-2 rounded-xl group-hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20">
              <ShoppingBag className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-extrabold text-white">Shop<span className="text-emerald-400">Vault</span></span>
          </Link>
          <div className="hidden md:flex items-center gap-1">
            <Link to="/" className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${on('/') ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}>Home</Link>
            {isAuthenticated && (
              <>
                <Link to="/products" className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${on('/products') ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}>Products</Link>
                <Link to="/products/new" className="flex items-center gap-1.5 ml-2 px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 text-white hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20">
                  <Plus className="w-4 h-4" /> Add Product
                </Link>
              </>
            )}
          </div>
          <div className="hidden md:flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <div className="flex items-center gap-2 text-slate-300">
                  <div className="bg-emerald-500/20 p-1.5 rounded-full border border-emerald-500/30"><User className="w-3.5 h-3.5 text-emerald-400" /></div>
                  <span className="text-sm font-medium">{user?.username}</span>
                </div>
                <button onClick={go} className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors">
                  <LogOut className="w-4 h-4" /> Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="px-4 py-2 rounded-lg text-sm font-medium text-slate-400 hover:text-white hover:bg-white/5">Login</Link>
                <Link to="/register" className="px-5 py-2 rounded-lg text-sm font-semibold bg-emerald-500 text-white hover:bg-emerald-400 shadow-lg shadow-emerald-500/20">Register</Link>
              </>
            )}
          </div>
          <button onClick={() => setOpen(!open)} className="md:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/10">
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="md:hidden border-t border-white/[.06] bg-[#0c1220] pb-4 px-4 pt-3 space-y-1">
          <Link to="/" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm text-slate-300 hover:bg-white/5">Home</Link>
          {isAuthenticated && (
            <>
              <Link to="/products" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm text-slate-300 hover:bg-white/5">Products</Link>
              <Link to="/products/new" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm font-medium text-emerald-400 hover:bg-emerald-500/10">+ Add Product</Link>
            </>
          )}
          <div className="border-t border-white/[.06] pt-2 mt-2">
            {isAuthenticated ? (
              <>
                <div className="px-4 py-2 text-sm text-slate-500">Signed in as <span className="text-white font-medium">{user?.username}</span></div>
                <button onClick={go} className="w-full text-left px-4 py-2.5 rounded-lg text-sm text-red-400 hover:bg-red-500/10">Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm text-slate-300 hover:bg-white/5">Login</Link>
                <Link to="/register" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm font-medium text-emerald-400 hover:bg-emerald-500/10">Register</Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}

import { Link } from 'react-router-dom';
import { Star, Package, ArrowUpRight } from 'lucide-react';
import type { Product } from '../types';

const emoji: Record<string, string> = {
  Electronics:'🖥️', Furniture:'🪑', 'Food & Beverage':'🍵',
  'Sports & Outdoors':'🏃', Clothing:'👕', Books:'📚',
  'Home & Garden':'🏡', 'Health & Beauty':'💄', Toys:'🧸', Automotive:'🚗',
};

export default function ProductCard({ product: p }: { product: Product }) {
  const inStock = p.stock > 0;
  return (
    <Link to={`/products/${p._id}`}
      className="group block rounded-2xl border border-white/[.07] bg-gradient-to-b from-white/[.04] to-transparent overflow-hidden hover:border-emerald-500/30 hover:shadow-xl hover:shadow-emerald-500/5 transition-all duration-300">
      <div className="h-44 relative overflow-hidden flex items-center justify-center bg-gradient-to-br from-slate-800/40 to-slate-900/40">
        <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl group-hover:scale-110 group-hover:-rotate-6 transition-transform duration-300 shadow-xl"
          style={{ background: `linear-gradient(135deg, ${p.color}30, ${p.color}10)`, border: `1px solid ${p.color}40` }}>
          {emoji[p.category] || <Package className="w-8 h-8 text-slate-400" />}
        </div>
        <div className="absolute top-3 right-3 bg-black/50 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
          <span className="text-sm font-bold text-emerald-400">${p.price.toFixed(2)}</span>
        </div>
        <div className={`absolute top-3 left-3 px-2 py-0.5 rounded-full text-[11px] font-semibold backdrop-blur-md border ${
          inStock ? p.stock <= 10 ? 'bg-amber-500/15 text-amber-400 border-amber-500/20' : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20' : 'bg-red-500/15 text-red-400 border-red-500/20'
        }`}>
          {inStock ? (p.stock <= 10 ? `${p.stock} left` : 'In Stock') : 'Sold Out'}
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">{p.brand}</span>
          <span className="text-slate-700">·</span>
          <span className="text-[11px] font-medium text-slate-500">{p.category}</span>
        </div>
        <h3 className="text-[15px] font-semibold text-slate-100 leading-snug line-clamp-2 group-hover:text-emerald-400 transition-colors min-h-[2.5rem]">{p.name}</h3>
        <p className="mt-1.5 text-[13px] text-slate-500 line-clamp-2 leading-relaxed">{p.description}</p>
        <div className="mt-3 pt-3 border-t border-white/[.06] flex items-center justify-between">
          <div className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span className="text-sm font-semibold text-slate-200">{p.rating}</span>
          </div>
          <span className="flex items-center gap-0.5 text-xs font-medium text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity">
            View <ArrowUpRight className="w-3.5 h-3.5" />
          </span>
        </div>
      </div>
    </Link>
  );
}

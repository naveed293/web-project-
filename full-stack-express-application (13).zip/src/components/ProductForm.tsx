import { useState } from 'react';
import { Save, X } from 'lucide-react';
import type { ProductFormData } from '../types';

const CATS = ['Electronics','Furniture','Food & Beverage','Sports & Outdoors','Clothing','Books','Home & Garden','Health & Beauty','Toys','Automotive','Other'];
const COLS = [
  {n:'Emerald',v:'#10b981'},{n:'Teal',v:'#14b8a6'},{n:'Cyan',v:'#06b6d4'},{n:'Sky',v:'#0ea5e9'},
  {n:'Blue',v:'#3b82f6'},{n:'Violet',v:'#8b5cf6'},{n:'Purple',v:'#a855f7'},{n:'Pink',v:'#ec4899'},
  {n:'Rose',v:'#f43f5e'},{n:'Orange',v:'#f97316'},{n:'Amber',v:'#f59e0b'},{n:'Lime',v:'#84cc16'},
];

interface Props { initialData?: Partial<ProductFormData>; onSubmit: (d: ProductFormData) => void; onCancel: () => void; submitLabel?: string; }

export default function ProductForm({ initialData, onSubmit, onCancel, submitLabel = 'Save Product' }: Props) {
  const [f, setF] = useState<ProductFormData>({
    name: initialData?.name ?? '', brand: initialData?.brand ?? '',
    category: initialData?.category ?? 'Electronics', price: initialData?.price ?? 0,
    stock: initialData?.stock ?? 0, description: initialData?.description ?? '',
    rating: initialData?.rating ?? 4, color: initialData?.color ?? '#10b981',
  });
  const [err, setErr] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!f.name.trim()) e.name = 'Product name is required';
    if (!f.brand.trim()) e.brand = 'Brand is required';
    if (!f.description.trim()) e.description = 'Description is required';
    else if (f.description.trim().length < 10) e.description = 'Min 10 characters';
    if (f.price < 0) e.price = 'Price cannot be negative';
    if (f.stock < 0 || !Number.isInteger(f.stock)) e.stock = 'Must be a whole number ≥ 0';
    if (f.rating < 0 || f.rating > 5) e.rating = 'Rating 0–5';
    setErr(e); return !Object.keys(e).length;
  };

  const go = (ev: React.FormEvent) => { ev.preventDefault(); if (validate()) onSubmit(f); };
  const set = (k: keyof ProductFormData, v: string | number) => {
    setF(p => ({ ...p, [k]: v }));
    if (err[k]) setErr(p => { const c = { ...p }; delete c[k]; return c; });
  };
  const cls = (k: string) =>
    `w-full px-4 py-2.5 bg-white/[.04] border rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-2 transition-all ${
      err[k] ? 'border-red-500/50 focus:ring-red-500/20' : 'border-white/[.08] focus:ring-emerald-500/20 focus:border-emerald-500/40'
    }`;

  return (
    <form onSubmit={go} className="space-y-5">
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-1.5">Product Name <span className="text-red-400">*</span></label>
        <input type="text" value={f.name} onChange={e => set('name', e.target.value)} placeholder="e.g. Wireless Headphones" className={cls('name')} />
        {err.name && <p className="mt-1 text-sm text-red-400">{err.name}</p>}
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-1.5">Brand <span className="text-red-400">*</span></label>
        <input type="text" value={f.brand} onChange={e => set('brand', e.target.value)} placeholder="e.g. SoundMax" className={cls('brand')} />
        {err.brand && <p className="mt-1 text-sm text-red-400">{err.brand}</p>}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div><label className="block text-sm font-medium text-slate-300 mb-1.5">Category</label>
          <select value={f.category} onChange={e => set('category', e.target.value)} className={cls('category')}>{CATS.map(c => <option key={c} className="bg-[#0c1220]">{c}</option>)}</select></div>
        <div><label className="block text-sm font-medium text-slate-300 mb-1.5">Stock Quantity</label>
          <input type="number" min="0" step="1" value={f.stock} onChange={e => set('stock', parseInt(e.target.value) || 0)} className={cls('stock')} />
          {err.stock && <p className="mt-1 text-sm text-red-400">{err.stock}</p>}</div>
      </div>
      <div><label className="block text-sm font-medium text-slate-300 mb-1.5">Price ($)</label>
        <input type="number" min="0" step="0.01" value={f.price} onChange={e => set('price', parseFloat(e.target.value) || 0)} className={cls('price')} />
        {err.price && <p className="mt-1 text-sm text-red-400">{err.price}</p>}</div>
      <div><label className="block text-sm font-medium text-slate-300 mb-1.5">Description <span className="text-red-400">*</span></label>
        <textarea value={f.description} onChange={e => set('description', e.target.value)} placeholder="Describe features..." rows={4} className={`${cls('description')} resize-none`} />
        {err.description && <p className="mt-1 text-sm text-red-400">{err.description}</p>}</div>
      <div><label className="block text-sm font-medium text-slate-300 mb-1.5">Rating: <span className="text-emerald-400 font-bold">{f.rating.toFixed(1)}</span> / 5</label>
        <input type="range" min="0" max="5" step="0.1" value={f.rating} onChange={e => set('rating', parseFloat(e.target.value))} className="w-full" />
        <div className="flex justify-between text-[11px] text-slate-600 mt-1"><span>0</span><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span></div></div>
      <div><label className="block text-sm font-medium text-slate-300 mb-2">Accent Color</label>
        <div className="flex flex-wrap gap-2">
          {COLS.map(c => (
            <button key={c.v} type="button" onClick={() => set('color', c.v)} title={c.n}
              className={`w-8 h-8 rounded-full transition-all duration-200 ${f.color === c.v ? 'ring-2 ring-offset-2 ring-offset-[#0c1220] ring-emerald-400 scale-110' : 'opacity-40 hover:opacity-100 hover:scale-105'}`}
              style={{ backgroundColor: c.v }} />
          ))}
        </div></div>
      <div className="flex items-center gap-3 pt-5 border-t border-white/[.06]">
        <button type="submit" className="flex items-center gap-2 px-6 py-2.5 bg-emerald-500 text-white rounded-xl font-semibold hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20">
          <Save className="w-4 h-4" /> {submitLabel}
        </button>
        <button type="button" onClick={onCancel} className="flex items-center gap-2 px-6 py-2.5 bg-white/[.06] text-slate-300 rounded-xl font-medium hover:bg-white/10 transition-colors border border-white/[.08]">
          <X className="w-4 h-4" /> Cancel
        </button>
      </div>
    </form>
  );
}

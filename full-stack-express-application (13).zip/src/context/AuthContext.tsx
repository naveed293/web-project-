import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { User, AuthState } from '../types';

interface AuthContextType extends AuthState {
  login: (username: string, password: string) => { success: boolean; error?: string };
  register: (username: string, email: string, password: string) => { success: boolean; error?: string };
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const USERS_KEY = 'bookshelf_users';
const SESSION_KEY = 'bookshelf_session';

function getStoredUsers(): Array<{ _id: string; username: string; email: string; password: string; createdAt: string }> {
  try {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function storeUsers(users: Array<{ _id: string; username: string; email: string; password: string; createdAt: string }>) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getSession(): User | null {
  try {
    const data = localStorage.getItem(SESSION_KEY);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

function setSession(user: User | null) {
  if (user) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(SESSION_KEY);
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>(() => {
    const user = getSession();
    return { user, isAuthenticated: !!user };
  });

  const login = useCallback((username: string, password: string) => {
    const users = getStoredUsers();
    const found = users.find(u => u.username === username && u.password === password);
    if (!found) {
      return { success: false, error: 'Invalid username or password' };
    }
    const user: User = { _id: found._id, username: found.username, email: found.email, createdAt: found.createdAt };
    setSession(user);
    setAuthState({ user, isAuthenticated: true });
    return { success: true };
  }, []);

  const register = useCallback((username: string, email: string, password: string) => {
    const users = getStoredUsers();
    if (users.find(u => u.username === username)) {
      return { success: false, error: 'Username already exists' };
    }
    if (users.find(u => u.email === email)) {
      return { success: false, error: 'Email already registered' };
    }
    const newUser = {
      _id: crypto.randomUUID(),
      username,
      email,
      password,
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    storeUsers(users);
    const user: User = { _id: newUser._id, username: newUser.username, email: newUser.email, createdAt: newUser.createdAt };
    setSession(user);
    setAuthState({ user, isAuthenticated: true });
    return { success: true };
  }, []);

  const logout = useCallback(() => {
    setSession(null);
    setAuthState({ user: null, isAuthenticated: false });
  }, []);

  return (
    <AuthContext.Provider value={{ ...authState, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

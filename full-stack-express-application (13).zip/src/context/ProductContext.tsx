import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Product, ProductFormData } from '../types';

interface ProductContextType {
  products: Product[];
  getById: (id: string) => Product | undefined;
  create: (data: ProductFormData, userId: string) => Product;
  update: (id: string, data: Partial<ProductFormData>) => Product | null;
  remove: (id: string) => boolean;
}

const Ctx = createContext<ProductContextType | null>(null);
const KEY = 'shopvault_products_v3';
const PAL = ['#10b981','#14b8a6','#06b6d4','#0ea5e9','#3b82f6','#8b5cf6','#a855f7','#ec4899','#f43f5e','#f97316','#f59e0b','#84cc16'];

const SEED: Product[] = [
  {
    _id: 's1', name: 'Wireless Noise-Cancelling Headphones', brand: 'SoundMax',
    category: 'Electronics', price: 199.99, stock: 54,
    description: 'Premium over-ear headphones with active noise cancellation, 30-hour battery life, and rich bass. Bluetooth 5.3 with multi-device pairing.',
    rating: 4.7, color: '#06b6d4', createdBy: 'system',
    createdAt: '2025-11-10T08:00:00Z', updatedAt: '2025-11-10T08:00:00Z',
  },
  {
    _id: 's2', name: 'Ergonomic Office Chair Pro', brand: 'ComfortZone',
    category: 'Furniture', price: 349.00, stock: 18,
    description: 'Adjustable lumbar support, breathable mesh back, and 4D armrests. All-day comfort with a 300 lbs capacity and 5-year warranty.',
    rating: 4.5, color: '#10b981', createdBy: 'system',
    createdAt: '2025-10-25T14:30:00Z', updatedAt: '2025-10-25T14:30:00Z',
  },
  {
    _id: 's3', name: 'Ultra-Slim Laptop 15"', brand: 'TechNova',
    category: 'Electronics', price: 1299.99, stock: 32,
    description: '13th-gen processor, 16 GB RAM, 512 GB SSD, 2.8K OLED display. Only 1.2 kg — built for creators on the go.',
    rating: 4.8, color: '#8b5cf6', createdBy: 'system',
    createdAt: '2025-12-01T09:15:00Z', updatedAt: '2025-12-01T09:15:00Z',
  },
  {
    _id: 's4', name: 'Organic Green Tea – 100 Bags', brand: 'PureLeaf',
    category: 'Food & Beverage', price: 14.99, stock: 210,
    description: 'From high-altitude Japanese farms. Rich in antioxidants with a smooth, earthy flavor. Individually wrapped for freshness.',
    rating: 4.3, color: '#14b8a6', createdBy: 'system',
    createdAt: '2025-09-18T11:45:00Z', updatedAt: '2025-09-18T11:45:00Z',
  },
  {
    _id: 's5', name: 'Running Shoes AirStride X', brand: 'VeloFit',
    category: 'Sports & Outdoors', price: 129.95, stock: 76,
    description: 'Lightweight with responsive foam cushioning and breathable knit upper. Reflective accents for low-light visibility.',
    rating: 4.6, color: '#f97316', createdBy: 'system',
    createdAt: '2025-08-05T16:00:00Z', updatedAt: '2025-08-05T16:00:00Z',
  },
  {
    _id: 's6', name: 'Smart Home Security Camera', brand: 'GuardEye',
    category: 'Electronics', price: 89.99, stock: 120,
    description: '1080p HD with night vision, two-way audio, motion alerts, and cloud storage. Works with Alexa and Google Home.',
    rating: 4.4, color: '#f43f5e', createdBy: 'system',
    createdAt: '2025-07-22T13:20:00Z', updatedAt: '2025-07-22T13:20:00Z',
  },
];

function load(): Product[] {
  try { const d = localStorage.getItem(KEY); if (d) return JSON.parse(d); localStorage.setItem(KEY, JSON.stringify(SEED)); return SEED; } catch { return SEED; }
}
function save(p: Product[]) { localStorage.setItem(KEY, JSON.stringify(p)); }

export function ProductProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(load);
  const getById = useCallback((id: string) => products.find(p => p._id === id), [products]);

  const create = useCallback((data: ProductFormData, userId: string) => {
    const now = new Date().toISOString();
    const p: Product = { ...data, _id: crypto.randomUUID(), color: data.color || PAL[Math.floor(Math.random() * PAL.length)], createdBy: userId, createdAt: now, updatedAt: now };
    setProducts(prev => { const n = [...prev, p]; save(n); return n; });
    return p;
  }, []);

  const update = useCallback((id: string, data: Partial<ProductFormData>) => {
    let out: Product | null = null;
    setProducts(prev => { const i = prev.findIndex(p => p._id === id); if (i === -1) return prev; out = { ...prev[i], ...data, updatedAt: new Date().toISOString() }; const n = [...prev]; n[i] = out; save(n); return n; });
    return out;
  }, []);

  const remove = useCallback((id: string) => {
    let ok = false;
    setProducts(prev => { const n = prev.filter(p => p._id !== id); ok = n.length < prev.length; save(n); return n; });
    return ok;
  }, []);

  return <Ctx.Provider value={{ products, getById, create, update, remove }}>{children}</Ctx.Provider>;
}

export function useProducts() { const c = useContext(Ctx); if (!c) throw new Error('useProducts must be inside ProductProvider'); return c; }

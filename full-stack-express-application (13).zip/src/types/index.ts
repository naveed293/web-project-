export interface Product {
  _id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  stock: number;
  description: string;
  rating: number;
  color: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  _id: string;
  username: string;
  email: string;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export type ProductFormData = Omit<Product, '_id' | 'createdBy' | 'createdAt' | 'updatedAt'>;

import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useProducts } from '../context/ProductContext';
import ProductCard from '../components/ProductCard';
import { Plus, Search, SlidersHorizontal, ShoppingBag, LayoutGrid, List, Star, Package, DollarSign } from 'lucide-react';

export default function ProductsListPage() {
  const { products } = useProducts();
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('All');
  const [sort, setSort] = useState<'newest'|'oldest'|'name'|'rating'|'price-low'|'price-high'|'stock'>('newest');
  const [view, setView] = useState<'grid'|'list'>('grid');

  const cats = useMemo(() => ['All', ...Array.from(new Set(products.map(p => p.category))).sort()], [products]);
  const emoji: Record<string, string> = { Electronics:'🖥️', Furniture:'🪑', 'Food & Beverage':'🍵', 'Sports & Outdoors':'🏃', Clothing:'👕', Books:'📚', 'Home & Garden':'🏡', 'Health & Beauty':'💄', Toys:'🧸', Automotive:'🚗' };

  const filtered = useMemo(() => {
    let r = [...products];
    if (search.trim()) { const q = search.toLowerCase(); r = r.filter(p => p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)); }
    if (cat !== 'All') r = r.filter(p => p.category === cat);
    switch (sort) {
      case 'newest': r.sort((a,b) => +new Date(b.createdAt) - +new Date(a.createdAt)); break;
      case 'oldest': r.sort((a,b) => +new Date(a.createdAt) - +new Date(b.createdAt)); break;
      case 'name': r.sort((a,b) => a.name.localeCompare(b.name)); break;
      case 'rating': r.sort((a,b) => b.rating - a.rating); break;
      case 'price-low': r.sort((a,b) => a.price - b.price); break;
      case 'price-high': r.sort((a,b) => b.price - a.price); break;
      case 'stock': r.sort((a,b) => b.stock - a.stock); break;
    }
    return r;
  }, [products, search, cat, sort]);

  const selCls = "px-3 py-2.5 bg-white/[.04] border border-white/[.08] rounded-xl text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20";

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-extrabold text-white">All Products</h1>
          <p className="text-slate-500 mt-1">{products.length} product{products.length !== 1 ? 's' : ''} in catalog</p>
        </div>
        <Link to="/products/new" className="flex items-center gap-2 px-5 py-2.5 bg-emerald-500 text-white rounded-xl font-semibold hover:bg-emerald-400 self-start shadow-lg shadow-emerald-500/20"><Plus className="w-4 h-4" /> Add Product</Link>
      </div>

      <div className="rounded-2xl border border-white/[.07] bg-white/[.02] p-4 mb-6">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products..."
              className="w-full pl-10 pr-4 py-2.5 bg-white/[.04] border border-white/[.08] rounded-xl text-slate-100 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500/40" />
          </div>
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-slate-500 flex-shrink-0" />
            <select value={cat} onChange={e => setCat(e.target.value)} className={selCls}>
              {cats.map(c => <option key={c} className="bg-[#0c1220]">{c}</option>)}
            </select>
          </div>
          <select value={sort} onChange={e => setSort(e.target.value as typeof sort)} className={selCls}>
            <option value="newest" className="bg-[#0c1220]">Newest</option><option value="oldest" className="bg-[#0c1220]">Oldest</option><option value="name" className="bg-[#0c1220]">Name A-Z</option>
            <option value="rating" className="bg-[#0c1220]">Top Rated</option><option value="price-low" className="bg-[#0c1220]">Price ↑</option><option value="price-high" className="bg-[#0c1220]">Price ↓</option><option value="stock" className="bg-[#0c1220]">Most Stock</option>
          </select>
          <div className="flex bg-white/[.04] rounded-xl p-1 border border-white/[.06] self-start">
            <button onClick={() => setView('grid')} className={`p-2 rounded-lg transition-colors ${view === 'grid' ? 'bg-white/10 text-white' : 'text-slate-500 hover:text-white'}`}><LayoutGrid className="w-4 h-4" /></button>
            <button onClick={() => setView('list')} className={`p-2 rounded-lg transition-colors ${view === 'list' ? 'bg-white/10 text-white' : 'text-slate-500 hover:text-white'}`}><List className="w-4 h-4" /></button>
          </div>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-white/[.07] bg-white/[.02] p-16 text-center">
          <ShoppingBag className="w-14 h-14 text-slate-700 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-400 mb-2">{products.length === 0 ? 'No products yet' : 'No matches found'}</h3>
          <p className="text-slate-500 mb-4">{products.length === 0 ? 'Add your first product.' : 'Try different filters.'}</p>
          {products.length === 0 && <Link to="/products/new" className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-500 text-white rounded-xl font-semibold hover:bg-emerald-400 shadow-lg shadow-emerald-500/20"><Plus className="w-4 h-4" /> Add Product</Link>}
        </div>
      ) : view === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">{filtered.map(p => <ProductCard key={p._id} product={p} />)}</div>
      ) : (
        <div className="space-y-2">
          {filtered.map(p => (
            <Link key={p._id} to={`/products/${p._id}`} className="flex items-center gap-4 rounded-2xl border border-white/[.07] bg-white/[.02] p-4 hover:border-emerald-500/25 transition-all group">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0 border border-white/[.08] bg-white/[.03]">{emoji[p.category] || <Package className="w-5 h-5 text-slate-500" />}</div>
              <div className="flex-1 min-w-0">
                <h3 className="text-slate-100 font-semibold group-hover:text-emerald-400 transition-colors truncate">{p.name}</h3>
                <p className="text-sm text-slate-500">{p.brand} · {p.category}</p>
              </div>
              <div className="hidden sm:flex items-center gap-5 text-xs text-slate-500 flex-shrink-0">
                <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />{p.rating}</span>
                <span className="flex items-center gap-1"><Package className="w-3.5 h-3.5" />{p.stock}</span>
                <span className="font-bold text-emerald-400 flex items-center gap-0.5"><DollarSign className="w-3.5 h-3.5" />{p.price.toFixed(2)}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

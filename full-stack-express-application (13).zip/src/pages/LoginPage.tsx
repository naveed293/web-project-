import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogIn, ShoppingBag, Eye, EyeOff, AlertCircle } from 'lucide-react';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const nav = useNavigate();
  const ic = "w-full px-4 py-2.5 bg-white/[.04] border border-white/[.08] rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500/40 transition-all";

  const submit = (e: React.FormEvent) => {
    e.preventDefault(); setError('');
    if (!username.trim() || !password.trim()) { setError('Please fill in all fields'); return; }
    setLoading(true);
    setTimeout(() => { const r = login(username.trim(), password); if (r.success) nav('/products'); else setError(r.error || 'Login failed'); setLoading(false); }, 500);
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-500/15 border border-emerald-500/20 mb-4">
            <ShoppingBag className="w-8 h-8 text-emerald-400" />
          </div>
          <h1 className="text-3xl font-extrabold text-white mb-2">Welcome Back</h1>
          <p className="text-slate-400">Sign in to manage your products</p>
        </div>
        <div className="rounded-2xl border border-white/[.07] bg-gradient-to-b from-white/[.04] to-transparent p-8">
          {error && <div className="mb-6 p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-sm text-red-400 flex items-center gap-2"><AlertCircle className="w-4 h-4 flex-shrink-0" />{error}</div>}
          <form onSubmit={submit} className="space-y-5">
            <div><label className="block text-sm font-medium text-slate-300 mb-1.5">Username</label>
              <input type="text" value={username} onChange={e => setUsername(e.target.value)} placeholder="Enter your username" autoComplete="username" className={ic} /></div>
            <div><label className="block text-sm font-medium text-slate-300 mb-1.5">Password</label>
              <div className="relative">
                <input type={show ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter your password" autoComplete="current-password" className={`${ic} pr-12`} />
                <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">{show ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}</button>
              </div></div>
            <button type="submit" disabled={loading} className="w-full flex items-center justify-center gap-2 py-3 bg-emerald-500 text-white rounded-xl font-semibold hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-lg shadow-emerald-500/20">
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><LogIn className="w-4 h-4" /> Sign In</>}
            </button>
          </form>
          <div className="mt-6 pt-6 border-t border-white/[.06] text-center"><p className="text-sm text-slate-500">Don&apos;t have an account? <Link to="/register" className="text-emerald-400 hover:text-emerald-300 font-medium">Create one</Link></p></div>
        </div>
      </div>
    </div>
  );
}

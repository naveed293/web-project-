import { Link } from 'react-router-dom';
import { useProducts } from '../context/ProductContext';
import { useAuth } from '../context/AuthContext';
import ProductCard from '../components/ProductCard';
import {
  ShoppingBag, Shield, Database, Layout, Server, Code,
  ArrowRight, Layers, Package, Star, DollarSign,
} from 'lucide-react';

export default function HomePage() {
  const { products } = useProducts();
  const { isAuthenticated } = useAuth();

  const tech = [
    { icon: Server,  label: 'Node.js + Express',  desc: 'Backend & routing' },
    { icon: Database, label: 'MongoDB + Mongoose', desc: 'Database & ODM' },
    { icon: Layout,  label: 'EJS Templates',      desc: 'View engine' },
    { icon: Code,    label: 'TailwindCSS',         desc: 'Utility CSS' },
    { icon: Shield,  label: 'Passport.js',         desc: 'Authentication' },
    { icon: Layers,  label: 'RESTful API',         desc: 'CRUD endpoints' },
  ];

  const totalValue = products.reduce((s, p) => s + p.price * p.stock, 0);
  const avgRating = products.length ? (products.reduce((s, p) => s + p.rating, 0) / products.length).toFixed(1) : '0';

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden py-28 sm:py-36">
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/[.04] via-transparent to-transparent pointer-events-none" />
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-emerald-500/[.06] rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-cyan-500/[.04] rounded-full blur-[100px] pointer-events-none" />

        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl sm:text-7xl font-black text-white mb-6 tracking-tight leading-[1.1]">
            Shop<span className="text-emerald-400">Vault</span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-400 max-w-xl mx-auto mb-10 leading-relaxed">
            A full-stack product management application built with
            <strong className="text-slate-200"> Node.js, Express, MongoDB, EJS, TailwindCSS </strong>
            and <strong className="text-slate-200">Passport.js</strong>.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            {isAuthenticated ? (
              <>
                <Link to="/products" className="flex items-center gap-2 px-8 py-3.5 bg-emerald-500 text-white rounded-xl font-semibold hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/25">
                  Browse Products <ArrowRight className="w-4 h-4" />
                </Link>
                <Link to="/products/new" className="px-8 py-3.5 text-slate-200 rounded-xl font-semibold border border-white/10 hover:bg-white/5 transition-colors">+ Add Product</Link>
              </>
            ) : (
              <>
                <Link to="/register" className="flex items-center gap-2 px-8 py-3.5 bg-emerald-500 text-white rounded-xl font-semibold hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/25">
                  Get Started <ArrowRight className="w-4 h-4" />
                </Link>
                <Link to="/login" className="px-8 py-3.5 text-slate-200 rounded-xl font-semibold border border-white/10 hover:bg-white/5 transition-colors">Sign In</Link>
              </>
            )}
          </div>

          <div className="mt-20 grid grid-cols-3 max-w-md mx-auto gap-8">
            {[
              { icon: Package,    val: products.length, label: 'Products' },
              { icon: Star,       val: avgRating,       label: 'Avg Rating' },
              { icon: DollarSign, val: `$${totalValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`, label: 'Inventory' },
            ].map(s => (
              <div key={s.label} className="text-center">
                <div className="w-12 h-12 rounded-xl border border-white/[.08] bg-white/[.03] flex items-center justify-center mx-auto mb-3">
                  <s.icon className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="text-2xl font-bold text-white">{s.val}</div>
                <div className="text-xs text-slate-500 mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TECH STACK */}
      <section className="py-20 border-y border-white/[.04]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mb-3">Technology Stack</h2>
            <p className="text-slate-500 max-w-lg mx-auto">Built with modern web technologies following MVC architecture.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {tech.map(t => (
              <div key={t.label} className="rounded-2xl border border-white/[.06] bg-white/[.02] p-5 text-center hover:border-emerald-500/25 hover:bg-emerald-500/[.04] transition-all group">
                <div className="w-11 h-11 rounded-xl border border-white/[.08] bg-white/[.03] flex items-center justify-center mx-auto mb-3 group-hover:border-emerald-500/30 group-hover:bg-emerald-500/10 transition-colors">
                  <t.icon className="w-5 h-5 text-emerald-400" />
                </div>
                <h3 className="text-sm font-semibold text-slate-200 mb-0.5">{t.label}</h3>
                <p className="text-xs text-slate-500">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white mb-2">Featured Products</h2>
              <p className="text-slate-500">Latest additions to the catalog</p>
            </div>
            {isAuthenticated && (
              <Link to="/products" className="hidden sm:flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-semibold transition-colors">
                View All <ArrowRight className="w-4 h-4" />
              </Link>
            )}
          </div>
          {products.length === 0 ? (
            <div className="rounded-2xl border border-white/[.07] bg-white/[.02] p-16 text-center">
              <ShoppingBag className="w-14 h-14 text-slate-700 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-400 mb-2">No products yet</h3>
              <p className="text-slate-500 mb-6">Be the first to add a product!</p>
              {isAuthenticated && (
                <Link to="/products/new" className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-500 text-white rounded-xl font-semibold hover:bg-emerald-400 shadow-lg shadow-emerald-500/20">Add Product</Link>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {products.slice(-6).reverse().map(p => <ProductCard key={p._id} product={p} />)}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

import { useParams, useNavigate, Link } from 'react-router-dom';
import { useProducts } from '../context/ProductContext';
import ProductForm from '../components/ProductForm';
import type { ProductFormData } from '../types';
import { Edit, ArrowLeft, ShoppingBag } from 'lucide-react';

export default function EditProductPage() {
  const { id } = useParams<{ id: string }>();
  const nav = useNavigate();
  const { getById, update } = useProducts();
  const p = id ? getById(id) : undefined;

  if (!p) return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
      <ShoppingBag className="w-16 h-16 text-slate-700 mx-auto mb-4" />
      <h1 className="text-2xl font-bold text-white mb-2">Product Not Found</h1>
      <Link to="/products" className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-500 text-white rounded-xl font-semibold hover:bg-emerald-400 shadow-lg shadow-emerald-500/20"><ArrowLeft className="w-4 h-4" /> Back</Link>
    </div>
  );

  const submit = (d: ProductFormData) => { if (id) { update(id, d); nav(`/products/${id}`); } };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link to={`/products/${p._id}`} className="inline-flex items-center gap-2 text-slate-500 hover:text-white transition-colors mb-6"><ArrowLeft className="w-4 h-4" /> Back to Product</Link>
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-amber-500/15 border border-amber-500/20 p-2.5 rounded-xl"><Edit className="w-5 h-5 text-amber-400" /></div>
          <h1 className="text-3xl font-extrabold text-white">Edit Product</h1>
        </div>
        <p className="text-slate-500 ml-[52px]">Updating "<strong className="text-slate-200">{p.name}</strong>"</p>
      </div>
      <div className="rounded-2xl border border-white/[.07] bg-gradient-to-b from-white/[.04] to-transparent p-6 sm:p-8">
        <ProductForm initialData={p} onSubmit={submit} onCancel={() => nav(`/products/${p._id}`)} submitLabel="Update Product" />
      </div>
    </div>
  );
}

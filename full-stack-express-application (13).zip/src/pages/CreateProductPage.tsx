import { useNavigate } from 'react-router-dom';
import { useProducts } from '../context/ProductContext';
import { useAuth } from '../context/AuthContext';
import ProductForm from '../components/ProductForm';
import type { ProductFormData } from '../types';
import { Plus } from 'lucide-react';

export default function CreateProductPage() {
  const nav = useNavigate();
  const { create } = useProducts();
  const { user } = useAuth();
  const submit = (d: ProductFormData) => { const p = create(d, user?._id || 'anon'); nav(`/products/${p._id}`); };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-emerald-500/15 border border-emerald-500/20 p-2.5 rounded-xl"><Plus className="w-5 h-5 text-emerald-400" /></div>
          <h1 className="text-3xl font-extrabold text-white">Add New Product</h1>
        </div>
        <p className="text-slate-500 ml-[52px]">Fill in the details to add a product to the catalog.</p>
      </div>
      <div className="rounded-2xl border border-white/[.07] bg-gradient-to-b from-white/[.04] to-transparent p-6 sm:p-8">
        <ProductForm onSubmit={submit} onCancel={() => nav('/products')} submitLabel="Create Product" />
      </div>
    </div>
  );
}

import { useParams, useNavigate, Link } from 'react-router-dom';
import { useProducts } from '../context/ProductContext';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';
import { ArrowLeft, Edit, Trash2, Star, Package, DollarSign, Calendar, ShoppingBag, Tag, BarChart3 } from 'lucide-react';

const emoji: Record<string, string> = { Electronics:'🖥️', Furniture:'🪑', 'Food & Beverage':'🍵', 'Sports & Outdoors':'🏃', Clothing:'👕', Books:'📚', 'Home & Garden':'🏡', 'Health & Beauty':'💄', Toys:'🧸', Automotive:'🚗' };

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const nav = useNavigate();
  const { getById, remove } = useProducts();
  const { user } = useAuth();
  const [del, setDel] = useState(false);
  const p = id ? getById(id) : undefined;

  if (!p) return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
      <ShoppingBag className="w-16 h-16 text-slate-700 mx-auto mb-4" />
      <h1 className="text-2xl font-bold text-white mb-2">Product Not Found</h1>
      <p className="text-slate-500 mb-6">This product may have been removed.</p>
      <Link to="/products" className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-500 text-white rounded-xl font-semibold hover:bg-emerald-400 shadow-lg shadow-emerald-500/20"><ArrowLeft className="w-4 h-4" /> Back</Link>
    </div>
  );

  const kill = () => { if (id) { remove(id); nav('/products'); } };
  const own = p.createdBy === user?._id || p.createdBy === 'system';
  const ok = p.stock > 0;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link to="/products" className="inline-flex items-center gap-2 text-slate-500 hover:text-white transition-colors mb-8"><ArrowLeft className="w-4 h-4" /> Back to Products</Link>

      <div className="rounded-2xl border border-white/[.07] bg-gradient-to-b from-white/[.04] to-transparent overflow-hidden">
        <div className="h-48 sm:h-56 relative overflow-hidden flex items-center justify-center bg-gradient-to-br from-slate-800/30 to-slate-900/50">
          <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl flex items-center justify-center text-6xl sm:text-7xl" style={{ background: `linear-gradient(135deg, ${p.color}25, ${p.color}08)`, border: `1px solid ${p.color}35` }}>{emoji[p.category] || '📦'}</div>
          <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 flex items-center gap-1">
            <DollarSign className="w-4 h-4 text-emerald-400" /><span className="text-xl font-extrabold text-emerald-400">{p.price.toFixed(2)}</span>
          </div>
          <div className={`absolute top-4 left-4 px-3 py-1.5 rounded-full text-sm font-semibold flex items-center gap-1.5 backdrop-blur-md border ${ok ? (p.stock <= 10 ? 'bg-amber-500/15 text-amber-400 border-amber-500/20' : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20') : 'bg-red-500/15 text-red-400 border-red-500/20'}`}>
            <Package className="w-4 h-4" />{ok ? `${p.stock} in stock` : 'Out of stock'}
          </div>
        </div>

        <div className="p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg" style={{ color: p.color, background: p.color + '15' }}>{p.category}</span>
              <h1 className="mt-3 text-2xl sm:text-3xl font-extrabold text-white leading-tight">{p.name}</h1>
              <p className="mt-1 text-lg text-slate-400">by <span className="text-slate-200 font-medium">{p.brand}</span></p>
            </div>
            {own && (
              <div className="flex items-center gap-2 flex-shrink-0">
                <Link to={`/products/${p._id}/edit`} className="flex items-center gap-2 px-4 py-2 bg-emerald-500 text-white rounded-xl text-sm font-semibold hover:bg-emerald-400 shadow-lg shadow-emerald-500/20"><Edit className="w-4 h-4" /> Edit</Link>
                <button onClick={() => setDel(true)} className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-400 border border-red-500/20 rounded-xl text-sm font-semibold hover:bg-red-500/20"><Trash2 className="w-4 h-4" /> Delete</button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
            <div className="rounded-xl p-4 border border-white/[.06] bg-white/[.02]">
              <div className="flex items-center gap-2 text-slate-500 text-sm mb-1.5"><Star className="w-4 h-4" /> Rating</div>
              <div className="flex items-center gap-1">{[1,2,3,4,5].map(s => <Star key={s} className={`w-4 h-4 ${s <= Math.round(p.rating) ? 'text-amber-400 fill-amber-400' : 'text-slate-700'}`} />)}<span className="ml-1 text-sm text-white font-bold">{p.rating}</span></div>
            </div>
            <div className="rounded-xl p-4 border border-white/[.06] bg-white/[.02]">
              <div className="flex items-center gap-2 text-slate-500 text-sm mb-1.5"><DollarSign className="w-4 h-4" /> Price</div>
              <span className="text-white font-bold text-lg">${p.price.toFixed(2)}</span>
            </div>
            <div className="rounded-xl p-4 border border-white/[.06] bg-white/[.02]">
              <div className="flex items-center gap-2 text-slate-500 text-sm mb-1.5"><BarChart3 className="w-4 h-4" /> Stock</div>
              <span className={`font-bold text-lg ${ok ? 'text-emerald-400' : 'text-red-400'}`}>{p.stock} units</span>
            </div>
            <div className="rounded-xl p-4 border border-white/[.06] bg-white/[.02]">
              <div className="flex items-center gap-2 text-slate-500 text-sm mb-1.5"><Calendar className="w-4 h-4" /> Added</div>
              <span className="text-slate-200 font-semibold text-sm">{new Date(p.createdAt).toLocaleDateString()}</span>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2"><Tag className="w-5 h-5 text-emerald-400" /> Description</h2>
            <p className="text-slate-400 leading-relaxed">{p.description}</p>
          </div>
        </div>
      </div>

      {del && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="rounded-2xl border border-white/[.1] bg-[#0f1726] p-6 max-w-sm w-full shadow-2xl text-center">
            <div className="w-12 h-12 bg-red-500/15 border border-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4"><Trash2 className="w-6 h-6 text-red-400" /></div>
            <h3 className="text-lg font-bold text-white mb-2">Delete Product</h3>
            <p className="text-slate-400 text-sm mb-6">Delete "<strong className="text-white">{p.name}</strong>"? This cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDel(false)} className="flex-1 py-2.5 bg-white/[.06] border border-white/[.08] text-slate-300 rounded-xl font-medium hover:bg-white/10">Cancel</button>
              <button onClick={kill} className="flex-1 py-2.5 bg-red-600 text-white rounded-xl font-medium hover:bg-red-500">Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
